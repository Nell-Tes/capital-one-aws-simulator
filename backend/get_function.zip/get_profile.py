import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('UserProfiles')

def lambda_handler(event, context):
    try:
        # This is to pass the ID in the URL like /user?id=12345
        user_id = event.get('queryStringParameters', {}).get('id')
        
        if not user_id:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Missing ID'})}

        response = table.get_item(Key={'UserId': int(user_id)})
        
        if 'Item' in response:
            return {
                'statusCode': 200,
                'headers': {
                    "Access-Control-Allow-Origin": "*",
                    "Access-Control-Allow-Headers": "Content-Type",
                    "Access-Control-Allow-Methods": "OPTIONS,GET"
                },
                'body': json.dumps(response['Item'], default=str)
            }
        else:
            return {'statusCode': 404, 'body': json.dumps({'error': 'User not found'})}

    except Exception as e:
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}